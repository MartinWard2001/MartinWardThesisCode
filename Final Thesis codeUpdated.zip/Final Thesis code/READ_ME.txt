The code for my thesis can be viewed in detail in the "Backend" python notebook. These functions are created and perform as describe in the thesis document. Each function is described with comments in this notebook.

The "Frontend" python notebook converts the functions from my backend code into a prototype User Interface. When the 4 cells are ran in this notebook, a user interface will appear. This allows the user to create .srt files, generate movie summaries, categorise the movie genre, identify themes, objects and actions from a movie and create MCQs. All of which is described in detail throughout the thesis document. The folder the "Frontend" python notebook is run in will create and populate folders with outputs from the user interface. 

*note:* The generating closed captions file takes a long process for bigger files, the User Interface may appear to "not be responding" in that time, however it is working to create your caption file in the background.

